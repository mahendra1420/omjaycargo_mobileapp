import 'package:flutter/material.dart';

class Helper{

  static verticalSpace(double size) {
    return SizedBox(
      height: size,
    );
  }

  static horizontalSpace(double size) {
    return SizedBox(
      width: size,
    );
  }


}