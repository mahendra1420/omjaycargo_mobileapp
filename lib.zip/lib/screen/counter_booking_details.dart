import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:omjaycargo/data/controller/booking_details_controller.dart';
import 'package:omjaycargo/helpers/helper.dart';

import '../assets/app_assets.dart';
import '../assets/app_colors.dart';
import '../data/controller/dashboard_controller.dart';
import '../data/shared_preference.dart';
import '../generated/l10n.dart';

class CounterBookingDetails extends StatefulWidget {
  const CounterBookingDetails({super.key});

  @override
  State<CounterBookingDetails> createState() => _CounterBookingDetailsState();
}

class _CounterBookingDetailsState extends State<CounterBookingDetails> {
  final double buttonSize = 30; // smaller size
  final CounterBookingDetailsController dashboardController = Get.put(CounterBookingDetailsController());
  @override
  void initState() {
    super.initState();
    _initDashboard();
  }

  void _initDashboard() async {
    final userId = await PreferenceManager.getUserId();
    if (userId != null) {
      dashboardController.bookingDetails(userId.toString());
    }

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.allScreenBGColor,
        automaticallyImplyLeading: false,
        title: Stack(
          alignment: Alignment.center,
          children: [
            Center(
              child: Text(
                S.current.counter_booking_view,
                style: TextStyle(
                  color: AppColors.bookingStatusCompleted,
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Align(
              alignment: Alignment.centerLeft,
              child: GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: buttonSize,
                  height: buttonSize,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: AppColors.bookingStatusCompleted),
                  ),
                  padding: const EdgeInsets.all(2),
                  child: Image.asset(
                    AppAssets.icBackIcon,
                    height: 10,
                    width: 10,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),

      body: Expanded(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: AppColors.allScreenBGColor,
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Text(
                          S.current.barcode_no,
                          style: TextStyle(
                            color: AppColors.bookingStatusCompleted,
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      Center(
                        child: Text(
                          "dsdsaxasceddac",
                          style: TextStyle(
                            color: AppColors.black,
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),

                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                LabelValueWidget(
                                  label: S.current.payment_type,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.zone_type,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.product,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.reference_no,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.length,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.height,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.pieces,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.recv_mob_no,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.sender_name,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.sender_address,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.remark,
                                  value: "Credit",
                                ),
                              ],
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                LabelValueWidget(
                                  label: S.current.customer_name,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.dest_country_pincode,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.doc_type,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.booking_date,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.weight_kg,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.width,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.additional,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.recv_pincode,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.is_cod,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.receiver_name,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.receiver_address,
                                  value: "Credit",
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              Helper.verticalSpace(10),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: AppColors.allScreenBGColor,
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Text(
                          S.current.applied_rate_charges,
                          style: TextStyle(
                            color: AppColors.bookingStatusCompleted,
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),

                      Helper.verticalSpace(10),

                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                LabelValueWidget(
                                  label: S.current.declared_value,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.pod_charge,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.cof,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.total_custom_charge,
                                  value: "Credit",
                                ),
                              ],
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                LabelValueWidget(
                                  label: S.current.courier_charge,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.delivery_charge,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.cof_amt,
                                  value: "Credit",
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Helper.verticalSpace(10),

                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                LabelValueWidget(
                                  label: S.current.declared_value,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.pod_charge,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.cof,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.total_custom_charge,
                                  value: "Credit",
                                ),
                              ],
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                LabelValueWidget(
                                  label: S.current.courier_charge,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.delivery_charge,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.cof_amt,
                                  value: "Credit",
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Helper.verticalSpace(10),

              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: AppColors.allScreenBGColor,
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Text(
                          "${S.current.sub_total_1} 86",
                          style: TextStyle(
                            color: AppColors.bookingStatusCompleted,
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),

                      Helper.verticalSpace(10),

                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                LabelValueWidget(
                                  label: S.current.fuel_surcharge,
                                  value: "Credit",
                                ),
                              ],
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                LabelValueWidget(
                                  label: S.current.fuel_surcharge_amt,
                                  value: "Credit",
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Helper.verticalSpace(10),

                      Center(
                        child: Text(
                          "${S.current.sub_total_2} 86",
                          style: TextStyle(
                            color: AppColors.bookingStatusCompleted,
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),

                      Helper.verticalSpace(10),

                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    LabelValueWidget(
                                      label: S.current.s_gst,
                                      value: "Credit",
                                    ),

                                    LabelValueWidget(
                                      label: S.current.s_gst_amt,
                                      value: "Credit",
                                    ),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    LabelValueWidget(
                                      label: S.current.c_gst,
                                      value: "Credit",
                                    ),

                                    LabelValueWidget(
                                      label: S.current.c_gst_amt,
                                      value: "Credit",
                                    ),
                                  ],
                                ),

                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    LabelValueWidget(
                                      label: S.current.i_gst,
                                      value: "Credit",
                                    ),

                                    LabelValueWidget(
                                      label: S.current.i_gst_amt,
                                      value: "Credit",
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                LabelValueWidget(
                                  label: S.current.total_tax,
                                  value: "Credit",
                                ),
                                LabelValueWidget(
                                  label: S.current.total_amt,
                                  value: "Credit",
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class LabelValueWidget extends StatelessWidget {
  final String label;
  final String value;

  const LabelValueWidget({super.key, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: AppColors.bookingStatusCompleted,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 4), // small spacing
        Text(
          value,
          style: TextStyle(
            color: AppColors.black,
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}
