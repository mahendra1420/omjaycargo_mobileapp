import 'package:flutter/material.dart';
import 'package:omjaycargo/assets/app_style.dart';
import 'package:omjaycargo/helpers/helper.dart';

import '../assets/app_assets.dart';
import '../assets/app_colors.dart';
import '../generated/l10n.dart';

class CreditBillList extends StatefulWidget {
  const CreditBillList({super.key});

  @override
  State<CreditBillList> createState() => _CreditBillListState();
}

class _CreditBillListState extends State<CreditBillList> {
  final double buttonSize = 30;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.allScreenBGColor,
        automaticallyImplyLeading: false,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.bookingStatusCompleted,width: 1.5),
            ),
            padding: const EdgeInsets.all(2),
            child: Image.asset(AppAssets.icBackIcon, height: 10, width: 10),
          ),
        ),
        title: Text(
          S.current.credit_bill_list,
          style: TextStyle(
            color: AppColors.bookingStatusCompleted,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true, // ✅ keeps title in center
        actions: [

          // First right icon
          GestureDetector(
            onTap: () {
              // 👉 Action for first icon
            },
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppColors.bookingStatusCompleted,width: 1.5),
              ),
              padding: const EdgeInsets.all(2),
              child: Image.asset(
                AppAssets.icBackIcon,
                height: buttonSize,
                width: buttonSize,
              ),
            ),
          ),
          // Second right icon
          GestureDetector(
            onTap: () {
              // 👉 Action for second icon
            },
            child: Container(
              margin: const EdgeInsets.only(right: 8, top: 8, bottom: 8),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppColors.bookingStatusCompleted,width: 1.5),
              ),
              padding: const EdgeInsets.all(2),
              child: Image.asset(
                AppAssets.icBackIcon,
                height: buttonSize,
                width: buttonSize,
              ),
            ),
          ),
        ],
      ),

      body: Expanded(
        child: SingleChildScrollView(
          child: Column(
            children: [
              ListView.builder(
                itemCount: 10,
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemBuilder: (context, index) {
                  return buildBillCard(
                    billNo: "",
                    billDate: "billDate",
                    isVoucherCreated: "isVoucherCreated",
                    billAmount: 10,
                    sgst: 10,
                    cgst: 10,
                    igst: 10,
                    totalAmt: 10,
                    onIconTap: () {},
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildBillCard({
    required String billNo,
    required String billDate,
    required String isVoucherCreated,
    required double billAmount,
    required double sgst,
    required double cgst,
    required double igst,
    required double totalAmt,
    required VoidCallback onIconTap,
  }) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 10,vertical: 4),
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.secoundPrimary, width: 2),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
        Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  height: 200,
                  width: 10,
                  decoration: BoxDecoration(
                      color: AppColors.secoundPrimary,
                      borderRadius: BorderRadius.only(bottomLeft: Radius.circular(8),topLeft:Radius.circular(8))
                  ),
                ),

                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding:  EdgeInsets.only(left: 6,right: 8,top: 12),
                      child: Text(S.current.bill_no,style: TextStyle(
                        color: AppColors.black,fontWeight: FontWeight.bold,fontSize: 18
                      ),),
                    ),
                    Container(
                      height: 18,
                      width: 90,
                      decoration: BoxDecoration(
                          color: AppColors.secoundPrimary,
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(left: 8.0),
                        child: Text("59",style: TextStyle(color: AppColors.white,fontSize: 12),),
                      ),
                    ),
                    Padding(
                      padding:  EdgeInsets.only(left: 6,right: 8,top: 12),
                      child: Text(S.current.bill_date,style: TextStyle(
                          color: AppColors.black,fontWeight: FontWeight.bold,fontSize: 18
                      ),),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4.0,horizontal: 8),
                      child: Text("2022-05-01",style: TextStyle(
                        fontSize: 11
                      ),),
                    ),

                  ],
                )
              ],
            ),





          ],
        ),
       Container(
         width: 0.8,
         height: 200,
         color: AppColors.secoundPrimary,
       ),

          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Row(
                children: [
                  Padding(
                    padding:  EdgeInsets.only(left: 12,right: 8,top: 12),
                    child: Text(S.current.is_voucher_created,style: TextStyle(
                        color: AppColors.black,fontWeight: FontWeight.bold,fontSize: 16
                    ),),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 2,top: 14),
                    child: Text("yes",style: TextStyle(
                        fontSize: 14
                    ),),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10.0,top: 8),
                child: Container(
                  height: 1,
                  width: 190,
                  color: AppColors.black,
                ),
              ),
              Row(
                children: [
                  Padding(
                    padding:  EdgeInsets.only(left: 12,right: 8,top: 12),
                    child: Text(S.current.bill_amount,style: TextStyle(
                        color: AppColors.black,fontWeight: FontWeight.bold,fontSize: 16
                    ),),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 2,top: 14),
                    child: Text("2722997.22",style: TextStyle(
                        fontSize: 14
                    ),),
                  ),



                ],
              ),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                   Column(
                     children: [
                       Padding(
                         padding:  EdgeInsets.only(left: 12,right: 8,top: 12),
                         child: Text(S.current.sgst,style: TextStyle(
                             color: AppColors.black,fontWeight: FontWeight.bold,fontSize: 16
                         ),),
                       ),
                       Padding(
                         padding: const EdgeInsets.only(left: 2,top: 0),
                         child: Text("21488.86",style: TextStyle(
                             fontSize: 14
                         ),),
                       ),
                     ],
                   ),
                    Helper.horizontalSpace(15),

                    Column(
                      children: [
                        Padding(
                          padding:  EdgeInsets.only(left: 12,right: 8,top: 12),
                          child: Text(S.current.cgst,style: TextStyle(
                              color: AppColors.black,fontWeight: FontWeight.bold,fontSize: 16
                          ),),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 2,top: 0),
                          child: Text("21488.86",style: TextStyle(
                              fontSize: 14
                          ),),
                        ),
                      ],
                    ),
                    Helper.horizontalSpace(15),
                    Column(
                      children: [
                        Padding(
                          padding:  EdgeInsets.only(left: 12,right: 8,top: 12),
                          child: Text(S.current.igst,style: TextStyle(
                              color: AppColors.black,fontWeight: FontWeight.bold,fontSize: 16
                          ),),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 2,top: 0),
                          child: Text("21488.86",style: TextStyle(
                              fontSize: 14
                          ),),
                        ),
                      ],
                    )
                  ],
                ),
              ),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding:  EdgeInsets.only(left: 12,right: 8,top: 12),
                        child: Text(S.current.total_amt,style: TextStyle(
                            color: AppColors.black,fontWeight: FontWeight.bold,fontSize: 16
                        ),),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 12,top: 0),
                        child: Text("319948",style: TextStyle(
                            fontSize: 14
                        ),),
                      ),
                    ],
                  ),
                  Helper.horizontalSpace(96),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: GestureDetector(
                      onTap: onIconTap,
                      child: Container(
                        margin: const EdgeInsets.only(top: 8),
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          border: Border.all(color: AppColors.secoundPrimary,width: 1.5),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.copy, color: Colors.red, size: 20),
                      ),
                    ),
                  ),
                ],
              ),



            ],
          )


        ],
      ),
    );
  }
}
