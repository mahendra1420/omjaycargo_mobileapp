import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:omjaycargo/assets/app_assets.dart';
import 'package:omjaycargo/assets/app_colors.dart';
import 'package:omjaycargo/data/controller/dashboard_controller.dart';
import 'package:omjaycargo/helpers/helper.dart';

import '../data/models/dashboard_model.dart';
import '../data/shared_preference.dart';
import '../generated/l10n.dart';
import '../helpers/screen_constant.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  final double buttonSize = 30; // smaller size
  final DashboardController dashboardController = Get.put(DashboardController());
  String? businessName;
  String? agentCode;
  @override
  void initState() {
    super.initState();
    _initDashboard();
  }

  void _initDashboard() async {
    final userId = await PreferenceManager.getUserId();
     businessName = await PreferenceManager.getFirstName();
    agentCode = await PreferenceManager.getAgentCode();
    if (userId != null) {
      dashboardController.dashboard(userId.toString());
    }
    setState(() {});

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.allScreenBGColor,
      appBar: AppBar(
        backgroundColor: AppColors.allScreenBGColor,

        actions: [
          Container(
            width: buttonSize,
            height: buttonSize,
            margin: const EdgeInsets.only(left: 8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: AppColors.bookingStatusCompleted),
            ),
            child: Padding(
              padding: const EdgeInsets.all(2.0),
              child: Image.asset(AppAssets.icDrawer, height: 10, width: 10),
            ),
          ),
          Spacer(),
          Text(
            S.current.dashboard,
            style: TextStyle(
              color: AppColors.bookingStatusCompleted,
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
          Spacer(),
          Container(
            width: buttonSize,
            height: buttonSize,
            margin: const EdgeInsets.only(right: 8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: AppColors.bookingStatusCompleted),
            ),
            child: Padding(
              padding: const EdgeInsets.all(2.0),
              child: Image.asset(AppAssets.icLogOut, height: 10, width: 10),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: Center(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "${businessName}",
                style: TextStyle(
                  color: AppColors.bookingStatusCompleted,
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Helper.verticalSpace(4),
              Text(
                "${S.current.account_code} ${agentCode}",
                style: TextStyle(color: AppColors.primary, fontSize: 18),
              ),
              Helper.verticalSpace(20),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade400,
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Column(
                      children: [
                        // Grid of 6 buttons
                        GridView(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 3,
                                mainAxisSpacing: 12,
                                crossAxisSpacing: 12,
                                childAspectRatio: 1,
                              ),
                          children: [
                            DashboardButton(
                              title: S.current.booking_details,
                              count: dashboardController.dashBoardResponse.value?.data?.bookingDetails.toString(),
                              onTap: () {
                                Navigator.of(
                                  context,
                                ).pushNamed(AppScreen.counterBookingList);
                              },
                            ),
                            DashboardButton(
                              title: S.current.invoice,
                              count: dashboardController.dashBoardResponse.value?.data?.invoice.toString(),
                              onTap: () {
                                Navigator.of(
                                  context,
                                ).pushNamed(AppScreen.creditBillList);
                              },
                            ),
                            DashboardButton(
                              title: S.current.rate_calculator,
                              icon: Icons.calculate,
                              onTap: () {
                                Navigator.of(
                                  context,
                                ).pushNamed(AppScreen.rateCalculator);
                              },
                            ),
                            DashboardButton(
                              title: S.current.account_ledger,
                              icon: Icons.account_balance_wallet,
                              onTap: () {
                                Navigator.of(
                                  context,
                                ).pushNamed(AppScreen.accountLedgerScreen);
                              },
                            ),
                            DashboardButton(
                              title: S.current.complaint_service,
                              icon: Icons.report_problem,
                              onTap: () {
                                Navigator.of(
                                  context,
                                ).pushNamed(AppScreen.complainHistory);
                              },
                            ),
                            DashboardButton(
                              title: S.current.service_availability,
                              icon: Icons.local_shipping,
                              onTap: () {
                                Navigator.of(
                                  context,
                                ).pushNamed(AppScreen.serviceAvailibilityScreen);
                              },
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),

                        // Outstanding Amount
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(
                            vertical: 12,
                            horizontal: 16,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.red.shade200),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children:  [
                              Text(
                                "Outstanding Amount",
                                style: TextStyle(fontWeight: FontWeight.w500),
                              ),
                              Text(
                                "${dashboardController.dashBoardResponse.value?.data?.outstandingAmt}",
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.red,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class DashboardButton extends StatelessWidget {
  final String title;
  final String? count;
  final IconData? icon;
  final VoidCallback? onTap;

  const DashboardButton({
    super.key,
    required this.title,
    this.count,
    this.icon,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.shade300,
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.red, size: 28),
            const SizedBox(height: 6),
            if (count != null)
              Text(
                count!,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.red,
                ),
              ),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}
