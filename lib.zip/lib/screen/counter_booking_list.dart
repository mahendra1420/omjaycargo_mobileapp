import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:omjaycargo/assets/app_colors.dart';
import 'package:omjaycargo/helpers/helper.dart';

import '../assets/app_assets.dart';
import '../data/controller/booking_details_controller.dart';
import '../data/shared_preference.dart';
import '../generated/l10n.dart';
import '../helpers/screen_constant.dart';

class CounterBookingList extends StatefulWidget {
  const CounterBookingList({super.key});

  @override
  State<CounterBookingList> createState() => _CounterBookingListState();
}

class _CounterBookingListState extends State<CounterBookingList> {
  final CounterBookingDetailsController counterBookingDetailsController =
      Get.put(CounterBookingDetailsController());
  @override
  void initState() {
    super.initState();
    _initDashboard();
  }

  void _initDashboard() async {
    final userId = await PreferenceManager.getUserId();
    if (userId != null) {
      counterBookingDetailsController.bookingDetails(userId.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    final double buttonSize = 30; // smaller size

    return Scaffold(
      // backgroundColor: AppColors.allScreenBGColor,
      appBar: AppBar(
        backgroundColor: AppColors.allScreenBGColor,
        automaticallyImplyLeading: false,

        actions: [
          Container(
            width: buttonSize,
            height: buttonSize,
            margin: const EdgeInsets.only(left: 8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: AppColors.bookingStatusCompleted),
            ),
            child: Padding(
              padding: const EdgeInsets.all(2.0),
              child: Image.asset(AppAssets.icBackIcon, height: 10, width: 10),
            ),
          ),
          Spacer(),
          Text(
            S.current.counter_booking,
            style: TextStyle(
              color: AppColors.bookingStatusCompleted,
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
          Spacer(),
          Container(
            width: buttonSize,
            height: buttonSize,
            margin: const EdgeInsets.only(right: 8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: AppColors.bookingStatusCompleted),
            ),
            child: Padding(
              padding: const EdgeInsets.all(2.0),
              child: Image.asset(AppAssets.icSearchIcon, height: 10, width: 10),
            ),
          ),
          Container(
            width: buttonSize,
            height: buttonSize,
            margin: const EdgeInsets.only(right: 8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: AppColors.bookingStatusCompleted),
            ),
            child: Padding(
              padding: const EdgeInsets.all(2.0),
              child: Image.asset(AppAssets.icFilterIcon, height: 10, width: 10),
            ),
          ),
        ],
      ),

      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Helper.verticalSpace(10),
            Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: AppColors.allScreenBGColor,
                borderRadius: BorderRadius.all(Radius.circular(10)),
              ),
              child: Padding(
                padding: const EdgeInsets.only(
                  left: 12.0,
                  right: 12,
                  top: 8,
                  bottom: 8,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Barcode\nNo.", textAlign: TextAlign.center),
                    Text("Date"),
                    Text("City"),
                    Text("Receiver\nName", textAlign: TextAlign.center),
                    Text("Action"),
                  ],
                ),
              ),
            ),
            Helper.verticalSpace(10),
            Expanded(
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: counterBookingDetailsController
                    .counterBookingDetailsResponse
                    .value
                    ?.data
                    ?.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4.0),
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: AppColors.allScreenBGColor,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.3),
                            spreadRadius: 1,
                            blurRadius: 4,
                            offset: const Offset(0, 0),
                          ),
                        ],
                      ),

                      child: Padding(
                        padding: const EdgeInsets.only(
                          left: 12.0,
                          right: 12,
                          top: 8,
                          bottom: 8,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "${counterBookingDetailsController.counterBookingDetailsResponse.value?.data?[index].barcodeNo}",
                              textAlign: TextAlign.center,
                              style: TextStyle(fontSize: 10),
                            ),
                            Text(
                              "${counterBookingDetailsController.counterBookingDetailsResponse.value?.data?[index].bookingDate}",
                           style: TextStyle(fontSize: 10), ),
                            Text(
                              "${counterBookingDetailsController.counterBookingDetailsResponse.value?.data?[index].destinationCity}",
                              style: TextStyle(fontSize: 10),),
                            Text(
                              "${counterBookingDetailsController.counterBookingDetailsResponse.value?.data?[index].receiverName}",
                              textAlign: TextAlign.center,
                              style: TextStyle(fontSize: 10), ),
                            GestureDetector(
                              onTap: () {
                                Navigator.of(
                                  context,
                                ).pushNamed(AppScreen.counterBookingDetails);
                              },
                              child: Image.asset(
                                AppAssets.icLogOut,
                                height: 20,
                                width: 20,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
