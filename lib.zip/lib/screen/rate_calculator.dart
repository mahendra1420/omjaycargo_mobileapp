import 'package:flutter/material.dart';
import 'package:omjaycargo/assets/app_colors.dart';

import '../assets/app_assets.dart';
import '../generated/l10n.dart';

class RateCalculator extends StatefulWidget {
  const RateCalculator({Key? key}) : super(key: key);

  @override
  State<RateCalculator> createState() => _RateCalculatorState();
}

class _RateCalculatorState extends State<RateCalculator> {
  final List<String> zoneTypes = ['domestic_zone', 'international_zone'];
  final List<String> countries = ['Select Country', 'India', 'USA', 'UAE'];
  final List<String> docTypes = ['NON-DOC', 'DOC'];

  String? selectedZone;
  String? selectedCountry;
  String? selectedDocType;
  final TextEditingController weightCtrl = TextEditingController();

  @override
  void dispose() {
    weightCtrl.dispose();
    super.dispose();
  }

  // helper to render label with a raised red star (superscript-like)
  Widget requiredLabel(String label, {bool required = true}) {
    const double labelFontSize = 16;
    final labelStyle = TextStyle(
      color: Colors.blue.shade900,
      fontSize: labelFontSize,
      fontWeight: FontWeight.bold,
    );

    return RichText(
      text: TextSpan(
        children: [
          TextSpan(text: label, style: labelStyle),
          if (required)
            // WidgetSpan + Transform.translate to simulate superscript *
            WidgetSpan(
              alignment: PlaceholderAlignment.top,
              child: Transform.translate(
                offset: const Offset(1, -4), // adjust vertical offset to taste
                child: Text(
                  '*',
                  textScaleFactor: 1.0,
                  style: TextStyle(
                    color: AppColors.secoundPrimary,
                    fontSize: labelFontSize * 1.15,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  InputDecoration inputDecor() {
    return InputDecoration(
      isDense: true,
      contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
    );
  }

  @override
  Widget build(BuildContext context) {
    // container width control
    final double horizontalPadding = 16;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.allScreenBGColor,
        automaticallyImplyLeading: false,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: AppColors.bookingStatusCompleted,
                width: 1.5,
              ),
            ),
            padding: const EdgeInsets.all(2),
            child: Image.asset(AppAssets.icBackIcon, height: 10, width: 10),
          ),
        ),
        title: Text(
          S.current.rate_master,
          style: TextStyle(
            color: AppColors.bookingStatusCompleted,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true, // ✅ keeps title in center
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.symmetric(
          horizontal: horizontalPadding,
          vertical: 18,
        ),
        child: Column(
          children: [
            // Card container
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 14),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                // pink soft shadow like screenshot
                boxShadow: [
                  BoxShadow(
                    color: Colors.pink.shade50,
                    blurRadius: 14,
                    spreadRadius: 4,
                    offset: const Offset(0, 4),
                  ),
                ],
                border: Border.all(color: Colors.grey.shade200),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            requiredLabel(
                              S.current.zone_type,
                            ), // replace with S.current.zone_type
                            DropdownButtonFormField<String>(
                              isExpanded: true,
                              value: selectedZone,
                              items: zoneTypes
                                  .map(
                                    (e) => DropdownMenuItem(
                                      value: e,
                                      child: Text(
                                        e,
                                        style: const TextStyle(
                                          color: Colors
                                              .black, // dropdown items text
                                          fontSize: 14,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                      ),
                                    ),
                                  )
                                  .toList(),
                              onChanged: (v) =>
                                  setState(() => selectedZone = v),
                              style: const TextStyle(
                                color: Colors.black, // selected value text
                                fontSize: 14,
                              ),
                              decoration: InputDecoration(
                                isDense: true,
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 8,
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(6),
                                  borderSide: const BorderSide(
                                    color: Colors.black,
                                  ), // default border
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(6),
                                  borderSide: const BorderSide(
                                    color: Colors.black,
                                    width: 1,
                                  ), // normal
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(6),
                                  borderSide: const BorderSide(
                                    color: Colors.black,
                                    width: 1,
                                  ), // when focused
                                ),
                                disabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(6),
                                  borderSide: const BorderSide(
                                    color: Colors.black54,
                                  ), // disabled state
                                ),
                              ),
                              hint: const Text(
                                'Select Zone',
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 14,
                                ),
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                              dropdownColor: Colors.white,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 12),

                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            requiredLabel(
                              S.current.dest_country_mandatory,
                            ),
                            DropdownButtonFormField<String>(
                              isExpanded: true,
                              value: selectedZone,
                              items: zoneTypes
                                  .map(
                                    (e) => DropdownMenuItem(
                                  value: e,
                                  child: Text(
                                    e,
                                    style: const TextStyle(
                                      color: Colors
                                          .black, // dropdown items text
                                      fontSize: 14,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                  ),
                                ),
                              )
                                  .toList(),
                              onChanged: (v) =>
                                  setState(() => selectedZone = v),
                              style: const TextStyle(
                                color: Colors.black, // selected value text
                                fontSize: 14,
                              ),
                              decoration: InputDecoration(
                                isDense: true,
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 8,
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(6),
                                  borderSide: const BorderSide(
                                    color: Colors.black,
                                  ), // default border
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(6),
                                  borderSide: const BorderSide(
                                    color: Colors.black,
                                    width: 1,
                                  ), // normal
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(6),
                                  borderSide: const BorderSide(
                                    color: Colors.black,
                                    width: 1,
                                  ), // when focused
                                ),
                                disabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(6),
                                  borderSide: const BorderSide(
                                    color: Colors.black54,
                                  ), // disabled state
                                ),
                              ),
                              hint: const Text(
                                'Select Zone',
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 14,
                                ),
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                              dropdownColor: Colors.white,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 12),

                  // Second row: Doc Type and Weight
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            requiredLabel(
                              S.current.doc_type,
                            ), // S.current.doc_type
                            DropdownButtonFormField<String>(
                              isExpanded: true,
                              value: selectedZone,
                              items: zoneTypes
                                  .map(
                                    (e) => DropdownMenuItem(
                                  value: e,
                                  child: Text(
                                    e,
                                    style: const TextStyle(
                                      color: Colors
                                          .black, // dropdown items text
                                      fontSize: 14,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                  ),
                                ),
                              )
                                  .toList(),
                              onChanged: (v) =>
                                  setState(() => selectedZone = v),
                              style: const TextStyle(
                                color: Colors.black, // selected value text
                                fontSize: 14,
                              ),
                              decoration: InputDecoration(
                                isDense: true,
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 8,
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(6),
                                  borderSide: const BorderSide(
                                    color: Colors.black,
                                  ), // default border
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(6),
                                  borderSide: const BorderSide(
                                    color: Colors.black,
                                    width: 1,
                                  ), // normal
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(6),
                                  borderSide: const BorderSide(
                                    color: Colors.black,
                                    width: 1,
                                  ), // when focused
                                ),
                                disabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(6),
                                  borderSide: const BorderSide(
                                    color: Colors.black54,
                                  ), // disabled state
                                ),
                              ),
                              hint: const Text(
                                'Select Zone',
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 14,
                                ),
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                              dropdownColor: Colors.white,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            requiredLabel(
                              S.current.weight_kg,
                              required: false,
                            ), // optional example
                            const SizedBox(height: 8),
                            TextFormField(
                              controller: weightCtrl,
                              decoration: InputDecoration(
                                isDense: true,
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 8,
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(6),
                                  borderSide: const BorderSide(
                                    color: Colors.black,
                                  ), // default border
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(6),
                                  borderSide: const BorderSide(
                                    color: Colors.black,
                                    width: 1,
                                  ), // normal
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(6),
                                  borderSide: const BorderSide(
                                    color: Colors.black,
                                    width: 1,
                                  ), // when focused
                                ),
                                disabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(6),
                                  borderSide: const BorderSide(
                                    color: Colors.black54,
                                  ), // disabled state
                                ),
                              ),

                              keyboardType: TextInputType.numberWithOptions(
                                decimal: true,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 18),

                  // Submit button centered
                  Center(
                    child: ElevatedButton(
                      onPressed: () {
                        // handle submit
                        // validate fields and send request or show error
                        // Example:
                        if (selectedZone == null ||
                            selectedCountry == null ||
                            selectedDocType == null ||
                            weightCtrl.text.trim().isEmpty) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Please fill all required fields'),
                            ),
                          );
                          return;
                        }

                        // TODO: submit logic
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red.shade600,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 36,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                      child: const Text(
                        'SUBMIT',
                        style: TextStyle(color: AppColors.white),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 18),

            // Applied Rate / Charges heading
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Text(
                'APPLIED RATE/CHARGES',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.blue.shade900,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
            ),

            // Table header small row like screenshot
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 6.0),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      'Service Name',
                      style: TextStyle(color: Colors.blue.shade700),
                    ),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Total',
                      style: TextStyle(color: Colors.blue.shade700),
                    ),
                  ),
                  SizedBox(width: 12),
                  SizedBox(
                    width: 60,
                    child: Text(
                      'Action',
                      style: TextStyle(color: Colors.blue.shade700),
                    ),
                  ),
                ],
              ),
            ),

            // leave space for list
            const SizedBox(height: 160),
          ],
        ),
      ),
    );
  }
}
