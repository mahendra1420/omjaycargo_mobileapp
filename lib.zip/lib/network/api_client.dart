import 'package:dio/dio.dart';
import '../data/shared_preference.dart';
import '../helpers/app_url.dart';
import 'api_exception.dart';

class ApiClient {
  final Dio _dio = Dio(BaseOptions(
    baseUrl: AppUrl.baseURL,
    connectTimeout: const Duration(seconds: 15),
    receiveTimeout: const Duration(seconds: 15),
    headers: {
      'Content-Type': 'application/json',
    },
  ));

  Future<dynamic> post(String endpoint, dynamic data, {bool useToken = true}) async {
    try {
      // ✅ Automatically get token from SharedPreferences if required
      String? token;
      if (useToken) {
        token = await PreferenceManager.getAccessToken();
        if (token != null && token.isNotEmpty) {
          _dio.options.headers['Authorization'] = 'Bearer $token';
        } else {
          print('⚠️ No token found in SharedPreferences');
        }
      }


      // ✅ Log the request details
      print('🟦 [API REQUEST]');
      print('➡️ URL: ${_dio.options.baseUrl}$endpoint');
      print('🧾 Headers: ${_dio.options.headers}');
      print('📦 Body: $data');

      // Send the request
      final response = await _dio.post(endpoint, data: data);

      // ✅ Log the response details
      print('🟩 [API RESPONSE]');
      print('✅ Status Code: ${response.statusCode}');
      print('📥 Data: ${response.data}');

      return response.data;
    } on DioException catch (e) {
      // ✅ Log errors
      print('🟥 [API ERROR]');
      print('❌ Type: ${e.type}');
      print('📄 Message: ${e.message}');
      print('📤 Request URL: ${e.requestOptions.uri}');
      if (e.response != null) {
        print('📥 Response: ${e.response?.data}');
      }

      throw ApiException.fromDioError(e);
    }
  }
}
